#!/bin/bash
cd /home/photo/photo_booth/app/ && source .venv/bin/activate && python app.py
